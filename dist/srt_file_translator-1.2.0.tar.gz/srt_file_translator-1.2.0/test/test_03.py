from srt_file_translator import Translator
import os

translator = Translator(key_path="bq_key.json")
translator.show_languages()
